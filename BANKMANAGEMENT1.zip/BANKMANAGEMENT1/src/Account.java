public class Account {
    private String accountNumber;
    private double balance;
    private double interestRate;

    public Account(String accountNumber, double balance, double interestRate) {
        this.accountNumber = accountNumber;
        this.balance = balance;
        this.interestRate = interestRate;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    @Override
    public String toString() {
        return "Account[AccountNumber=" + accountNumber + ", Balance=" + balance + "]";
    }
}