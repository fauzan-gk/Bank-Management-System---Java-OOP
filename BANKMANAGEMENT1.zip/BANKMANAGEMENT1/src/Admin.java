public class Admin extends Person implements LoanManagement {
    private Bank bank;
    private String pinCode;

    public Admin(String name, String id, String contactInfo, String pinCode, Bank bank) {
        super(name, id, contactInfo);
        this.pinCode = pinCode;
        this.bank = bank;
    }

    public boolean verifyPin(String pin) {
        return this.pinCode.equals(pin);
    }

    public void hireEmployee(String name, String contactInfo, double salary, String pinCode) {
        String employeeId = "E" + String.format("%03d", bank.getEmployees().size() + 1);
        Employee newEmployee = new Employee(name, employeeId, contactInfo, salary, pinCode);
        bank.addEmployee(newEmployee);
        System.out.println("Employee hired: " + name);
    }

    public void fireEmployee(String employeeId) {
        bank.removeEmployee(employeeId);
        System.out.println("Employee fired: ID = " + employeeId);
    }

    public void manageSalary(String employeeId, double newSalary) {
        Employee employee = bank.findEmployeeById(employeeId);
        if (employee != null) {
            System.out.println("Updated salary for employee: " + employee.getName());
        } else {
            System.out.println("Employee not found.");
        }
    }

    public void addBonus(String employeeId, double bonus) {
        Employee employee = bank.findEmployeeById(employeeId);
        if (employee != null) {
            System.out.println("Bonus added to employee: " + employee.getName());
        } else {
            System.out.println("Employee not found.");
        }
    }

    @Override
    public void applyForLoan(Loan loan) {
        
    }

    @Override
    public void approveLoan(String loanId) {
        bank.approveLoan(loanId);
        System.out.println("Loan approved: ID = " + loanId);
    }

    @Override
    public void viewAllLoans() {
        bank.displayAllLoans();
    }

    @Override
    public void viewLoans() {

    }

    @Override
    public void displayDetails() {
        System.out.println("Admin Details: Name = " + name + ", ID = " + id);
    }
}
