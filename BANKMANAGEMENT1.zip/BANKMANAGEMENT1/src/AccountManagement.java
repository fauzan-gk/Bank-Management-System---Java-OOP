// Interfaces for modularity
public interface AccountManagement {
    void openAccount(Account account);
    void closeAccount(String accountNumber);
    void listAccounts();
}
